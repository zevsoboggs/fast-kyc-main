'use client';

import Link from "next/link";
import { useEffect, useState, useRef } from "react";

export default function Home() {
  const [mounted, setMounted] = useState(false);
  const [visibleSections, setVisibleSections] = useState<Set<string>>(new Set());

  useEffect(() => {
    setMounted(true);

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleSections((prev) => new Set(prev).add(entry.target.id));
          }
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('[data-animate]').forEach((el) => {
      observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <nav className="bg-white border-b border-gray-200 fixed top-0 left-0 right-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-gray-900 to-gray-700 rounded-lg flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-lg">V</span>
            </div>
            <div>
              <h1 className="text-lg font-semibold text-gray-900">veriffy.me</h1>
              <p className="text-xs text-gray-600">Верификация нового поколения</p>
            </div>
          </div>
          <div>
            <Link href="/login" className="px-4 py-2 bg-gray-900 text-white text-sm font-medium rounded-lg hover:bg-gray-800 transition-all hover:shadow-lg hover:scale-105">
              Войти
            </Link>
          </div>
        </div>
      </nav>

      <main className="flex-1 pt-24 px-6 pb-20">
        <div className="max-w-6xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <div className="inline-block mb-4 px-4 py-2 bg-gradient-to-r from-gray-100 to-gray-50 rounded-full border border-gray-200 shadow-sm animate-fade-in">
              <span className="text-gray-700 font-medium text-sm">🚀 Собственная технология распознавания</span>
            </div>
            <h2 className="text-5xl md:text-6xl font-bold mb-6 text-gray-900 animate-slide-up">
              Верификация личности<br />
              <span className="bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                нового поколения
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-10 animate-slide-up" style={{ animationDelay: '0.1s' }}>
              Автоматизированная проверка документов на базе собственных алгоритмов.<br />
              Быстро, безопасно и в соответствии с международными стандартами.
            </p>
            <div className="flex gap-4 justify-center flex-wrap animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <Link href="/register" className="px-8 py-4 bg-gradient-to-r from-gray-900 to-gray-700 text-white text-lg font-medium rounded-lg hover:shadow-2xl transition-all hover:scale-105">
                Начать бесплатно
              </Link>
              <Link href="/login" className="px-8 py-4 bg-white text-gray-900 border border-gray-300 text-lg font-medium rounded-lg hover:bg-gray-50 transition-all hover:shadow-lg hover:scale-105">
                Войти
              </Link>
            </div>
            <div className="mt-8 flex items-center justify-center gap-6 text-sm text-gray-500 flex-wrap">
              <span className="flex items-center gap-1">
                ✓ Без кредитной карты
              </span>
              <span className="flex items-center gap-1">
                ✓ Настройка за 5 минут
              </span>
              <span className="flex items-center gap-1">
                ✓ Поддержка 24/7
              </span>
            </div>
          </div>

          {/* Stats Section */}
          <div
            id="stats-section"
            data-animate
            className={`mt-20 mb-20 grid md:grid-cols-4 gap-6 transition-all duration-1000 ${
              visibleSections.has('stats-section') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
          >
            <StatCard
              number="99.9"
              suffix="%"
              label="Точность"
              delay={0}
              isVisible={visibleSections.has('stats-section')}
            />
            <StatCard
              number="5"
              suffix=" сек"
              label="Средняя скорость"
              delay={100}
              isVisible={visibleSections.has('stats-section')}
            />
            <StatCard
              number="180"
              suffix="+"
              label="Стран"
              delay={200}
              isVisible={visibleSections.has('stats-section')}
            />
            <StatCard
              number="24"
              suffix="/7"
              label="Поддержка"
              delay={300}
              isVisible={visibleSections.has('stats-section')}
            />
          </div>

          {/* How it works - Step by Step */}
          <div
            id="how-it-works"
            data-animate
            className={`mt-32 mb-32 transition-all duration-1000 ${
              visibleSections.has('how-it-works') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
          >
            <div className="text-center mb-16">
              <h3 className="text-4xl font-bold mb-4 text-gray-900">Как это работает</h3>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Простой процесс верификации всего за 4 шага
              </p>
            </div>

            <div className="relative">
              {/* Connection Line */}
              <div className="hidden md:block absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 -translate-y-1/2 z-0">
                <div
                  className={`h-full bg-gradient-to-r from-gray-900 to-gray-600 transition-all duration-2000 ${
                    visibleSections.has('how-it-works') ? 'w-full' : 'w-0'
                  }`}
                />
              </div>

              <div className="grid md:grid-cols-4 gap-8 relative z-10">
                <StepCard
                  number={1}
                  title="Загрузка документа"
                  description="Пользователь делает фото документа через камеру или загружает файл"
                  icon={
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  }
                  delay={0}
                  isVisible={visibleSections.has('how-it-works')}
                />
                <StepCard
                  number={2}
                  title="Сканирование лица"
                  description="Биометрическое сканирование с проверкой живости для защиты от подделок"
                  icon={
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                  }
                  delay={200}
                  isVisible={visibleSections.has('how-it-works')}
                />
                <StepCard
                  number={3}
                  title="Анализ данных"
                  description="Автоматическое извлечение и проверка данных с использованием OCR и AI"
                  icon={
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                  }
                  delay={400}
                  isVisible={visibleSections.has('how-it-works')}
                />
                <StepCard
                  number={4}
                  title="Результат"
                  description="Мгновенное получение результата с детальным отчетом о верификации"
                  icon={
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  }
                  delay={600}
                  isVisible={visibleSections.has('how-it-works')}
                />
              </div>
            </div>
          </div>

          {/* Features Grid */}
          <div
            id="features"
            data-animate
            className={`grid md:grid-cols-3 gap-6 mt-20 transition-all duration-1000 ${
              visibleSections.has('features') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
          >
            <FeatureCard
              icon={
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              }
              title="Распознавание документов"
              description="Автоматическое извлечение данных из паспортов и ID с поддержкой MRZ. Наши алгоритмы обеспечивают точность более 99%."
              delay={0}
            />
            <FeatureCard
              icon={
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
              }
              title="Биометрическое сравнение"
              description="Распознавание лиц и проверка живости с помощью собственных биометрических алгоритмов для защиты от подделок."
              delay={100}
            />
            <FeatureCard
              icon={
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              }
              title="Детекция мошенничества"
              description="Многоуровневая система оценки рисков на основе собственных алгоритмов с настраиваемыми правилами безопасности."
              delay={200}
            />
          </div>

          {/* Why Choose Us */}
          <div
            id="why-choose"
            data-animate
            className={`mt-24 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white rounded-2xl p-12 shadow-2xl transition-all duration-1000 ${
              visibleSections.has('why-choose') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
          >
            <div className="text-center mb-12">
              <h3 className="text-3xl font-semibold mb-4">Почему выбирают veriffy.me</h3>
              <p className="text-lg text-gray-300 max-w-2xl mx-auto">
                Наша собственная технология обеспечивает непревзойденную точность и скорость верификации
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <BenefitCard
                icon={
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                }
                title="Молниеносная скорость"
                description="Проверка документов занимает 5-10 секунд благодаря оптимизированным алгоритмам обработки"
              />
              <BenefitCard
                icon={
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                }
                title="Высокая точность"
                description="Более 99% точности распознавания документов и биометрического сравнения лиц"
              />
              <BenefitCard
                icon={
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                }
                title="Максимальная безопасность"
                description="Шифрование данных, защита от спуфинга и многоуровневая проверка подлинности"
              />
              <BenefitCard
                icon={
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 21v-4m0 0V5a2 2 0 012-2h6.5l1 1H21l-3 6 3 6h-8.5l-1-1H5a2 2 0 00-2 2zm9-13.5V9" />
                  </svg>
                }
                title="Поддержка всех документов"
                description="Паспорта, ID карты, водительские удостоверения из более чем 180 стран"
              />
            </div>
          </div>

          {/* Integration Section */}
          <div
            id="integration"
            data-animate
            className={`mt-24 transition-all duration-1000 ${
              visibleSections.has('integration') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
          >
            <div className="bg-white border border-gray-200 rounded-2xl p-12 shadow-lg">
              <div className="grid md:grid-cols-2 gap-12 items-center">
                <div>
                  <h3 className="text-3xl font-bold mb-4 text-gray-900">Простая интеграция</h3>
                  <p className="text-lg text-gray-600 mb-6">
                    Подключите верификацию к вашему сервису за несколько минут с помощью нашего API
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-center gap-3">
                      <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                        <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="text-gray-700">RESTful API с подробной документацией</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                        <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="text-gray-700">Webhook для real-time уведомлений</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                        <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="text-gray-700">SDK для популярных языков</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                        <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="text-gray-700">Готовые виджеты для веб и мобильных приложений</span>
                    </li>
                  </ul>
                </div>
                <div className="bg-gray-900 rounded-xl p-6 shadow-2xl">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                  <pre className="text-green-400 text-sm font-mono overflow-x-auto">
{`const response = await fetch(
  'https://api.veriffy.me/verify',
  {
    method: 'POST',
    headers: {
      'X-API-Key': 'your_api_key'
    },
    body: formData
  }
);

const result = await response.json();
// { status: 'APPROVED', ... }`}
                  </pre>
                </div>
              </div>
            </div>
          </div>

          {/* CTA Section */}
          <div
            id="cta"
            data-animate
            className={`mt-24 bg-white border border-gray-200 rounded-2xl p-12 text-center shadow-lg transition-all duration-1000 ${
              visibleSections.has('cta') ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
            }`}
          >
            <h3 className="text-3xl font-semibold mb-4 text-gray-900">Готовы начать?</h3>
            <p className="text-lg text-gray-600 mb-8">Создайте аккаунт и начните верифицировать пользователей</p>
            <Link href="/register" className="inline-block px-12 py-4 bg-gradient-to-r from-gray-900 to-gray-700 text-white text-lg font-medium rounded-lg hover:shadow-2xl transition-all hover:scale-105">
              Создать аккаунт бесплатно
            </Link>
            <p className="mt-4 text-sm text-gray-500">Без кредитной карты • Настройка за 5 минут</p>
          </div>
        </div>
      </main>

      <footer className="bg-white border-t border-gray-200 py-8 px-6 mt-20">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-between items-center flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-gray-900 to-gray-700 rounded-lg flex items-center justify-center shadow-lg">
                <span className="text-white font-bold">V</span>
              </div>
              <div>
                <p className="font-semibold text-gray-900 text-sm">veriffy.me</p>
                <p className="text-xs text-gray-600">Верификация нового поколения</p>
              </div>
            </div>
            <div className="text-gray-600 text-sm">
              <p>© 2025 veriffy.me • Собственная технология верификации</p>
            </div>
          </div>
        </div>
      </footer>

      <style jsx global>{`
        @keyframes fade-in {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes slide-up {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes pulse-glow {
          0%, 100% {
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
          }
          50% {
            box-shadow: 0 0 30px rgba(0, 0, 0, 0.2);
          }
        }

        .animate-fade-in {
          animation: fade-in 0.6s ease-out;
        }

        .animate-slide-up {
          animation: slide-up 0.6s ease-out;
        }

        .duration-2000 {
          transition-duration: 2000ms;
        }
      `}</style>
    </div>
  );
}

function StatCard({ number, suffix, label, delay, isVisible }: {
  number: string;
  suffix: string;
  label: string;
  delay: number;
  isVisible: boolean;
}) {
  const [count, setCount] = useState(0);
  const targetNumber = parseFloat(number);

  useEffect(() => {
    if (!isVisible) return;

    const duration = 2000;
    const steps = 60;
    const increment = targetNumber / steps;
    let current = 0;

    const timer = setInterval(() => {
      current += increment;
      if (current >= targetNumber) {
        setCount(targetNumber);
        clearInterval(timer);
      } else {
        setCount(current);
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [isVisible, targetNumber]);

  return (
    <div
      className="bg-white border border-gray-200 rounded-xl p-6 text-center hover:shadow-xl transition-all hover:scale-105"
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div className="text-4xl font-bold text-gray-900 mb-2">
        {isVisible ? count.toFixed(number.includes('.') ? 1 : 0) : '0'}{suffix}
      </div>
      <div className="text-sm text-gray-600">{label}</div>
    </div>
  );
}

function StepCard({ number, title, description, icon, delay, isVisible }: {
  number: number;
  title: string;
  description: string;
  icon: React.ReactNode;
  delay: number;
  isVisible: boolean;
}) {
  return (
    <div
      className={`relative transition-all duration-700 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div className="bg-white border-2 border-gray-200 rounded-xl p-6 hover:shadow-2xl transition-all hover:scale-105 hover:border-gray-900 group">
        <div className="flex justify-center mb-4">
          <div className="relative">
            <div className="w-16 h-16 bg-gradient-to-br from-gray-900 to-gray-700 rounded-full flex items-center justify-center text-white shadow-lg group-hover:shadow-2xl transition-all">
              {icon}
            </div>
            <div className="absolute -top-2 -right-2 w-8 h-8 bg-white border-2 border-gray-900 rounded-full flex items-center justify-center text-sm font-bold text-gray-900 shadow-md">
              {number}
            </div>
          </div>
        </div>
        <h4 className="text-lg font-semibold mb-2 text-gray-900 text-center">{title}</h4>
        <p className="text-sm text-gray-600 text-center leading-relaxed">{description}</p>
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, description, delay }: {
  icon: React.ReactNode;
  title: string;
  description: string;
  delay: number;
}) {
  return (
    <div
      className="bg-white border border-gray-200 rounded-xl p-8 hover:shadow-2xl transition-all hover:scale-105 hover:border-gray-900 group"
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div className="w-12 h-12 bg-gradient-to-br from-gray-900 to-gray-700 rounded-lg flex items-center justify-center mb-4 group-hover:shadow-lg transition-all">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-3 text-gray-900">{title}</h3>
      <p className="text-gray-600 leading-relaxed text-sm">
        {description}
      </p>
    </div>
  );
}

function BenefitCard({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="flex items-start gap-4 group hover:bg-white hover:bg-opacity-5 p-4 rounded-lg transition-all">
      <div className="w-10 h-10 bg-white bg-opacity-10 rounded-lg flex items-center justify-center flex-shrink-0 mt-1 group-hover:bg-opacity-20 transition-all">
        {icon}
      </div>
      <div>
        <h4 className="text-lg font-semibold mb-2">{title}</h4>
        <p className="text-gray-300 text-sm">
          {description}
        </p>
      </div>
    </div>
  );
}
